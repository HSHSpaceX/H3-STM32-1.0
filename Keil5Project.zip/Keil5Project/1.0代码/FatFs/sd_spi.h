#ifndef __SD_SPI_H
#define __SD_SPI_H

#include "stm32f10x.h"

void SD_SPI_Init(void);
uint8_t SD_SPI_SendReceive(uint8_t data);
void SD_CS_High(void);
void SD_CS_Low(void);
uint8_t SD_Init(void);                    // SD????
uint8_t SD_ReadSingleBlock(uint32_t sector, uint8_t *buffer);
uint8_t SD_WriteSingleBlock(uint32_t sector, uint8_t *buffer);

#endif
