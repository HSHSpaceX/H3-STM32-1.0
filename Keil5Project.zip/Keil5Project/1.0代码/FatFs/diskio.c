#include "ff.h"          // ???????,?????
#include "diskio.h"
#include "sd_spi.h"

DSTATUS disk_initialize(BYTE pdrv)
{
    if(pdrv != 0) return STA_NOINIT;
    return SD_Init() ? STA_NOINIT : 0;
}

DSTATUS disk_status(BYTE pdrv)
{
    return RES_OK;
}

DRESULT disk_read(BYTE pdrv, BYTE* buff, LBA_t sector, UINT count)
{
    if(pdrv || !count) return RES_PARERR;
    for(UINT i=0; i<count; i++) {
        if(SD_ReadSingleBlock((uint32_t)(sector + i), buff + i*512) != 0)
            return RES_ERROR;
    }
    return RES_OK;
}

DRESULT disk_write(BYTE pdrv, const BYTE* buff, LBA_t sector, UINT count)
{
    if(pdrv || !count) return RES_PARERR;
    for(UINT i=0; i<count; i++) {
        if(SD_WriteSingleBlock((uint32_t)(sector + i), (uint8_t*)(buff + i*512)) != 0)
            return RES_ERROR;
    }
    return RES_OK;
}

DRESULT disk_ioctl(BYTE pdrv, BYTE cmd, void* buff)
{
    if(cmd == GET_SECTOR_COUNT) *(DWORD*)buff = 0xFFFFFFFF;
    if(cmd == GET_BLOCK_SIZE)   *(DWORD*)buff = 1;
    return RES_OK;
}
