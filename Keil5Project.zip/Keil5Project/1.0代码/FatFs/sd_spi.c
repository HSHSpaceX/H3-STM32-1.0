#include "sd_spi.h"
#include "Delay.h"

#define SD_CS_GPIO      GPIOA
#define SD_CS_PIN       GPIO_Pin_4

void SD_SPI_Init(void)
{
    RCC->APB2ENR |= RCC_APB2ENR_SPI1EN | RCC_APB2ENR_IOPAEN | RCC_APB2ENR_IOPCEN;

    // PA5 SCK, PA7 MOSI: AF PP 50MHz
    GPIOA->CRL = (GPIOA->CRL & 0x0000FFFF) | 0xB4B00000;
    // PA6 MISO: ????
    GPIOA->CRL = (GPIOA->CRL & 0xFFF0FFFF) | 0x00040000;
    // PA4 CS: ????
    GPIOA->CRL = (GPIOA->CRL & 0xFFFFF0FF) | 0x00000300;
    GPIO_SetBits(GPIOA, GPIO_Pin_4);                     // CS?

    // PC14 CD: ????
    GPIOC->CRH = (GPIOC->CRH & 0xFFFF0FFF) | 0x00004000;
    GPIOC->ODR |= GPIO_Pin_14;

    SPI1->CR1 = 0;
    SPI1->CR1 = SPI_CR1_MSTR | SPI_CR1_SSI | SPI_CR1_SSM |
                SPI_CR1_SPE | SPI_CR1_BR_2 | SPI_CR1_BR_1;   // ?????(?281kHz)
    SPI1->CR2 = 0;
}

uint8_t SD_SPI_SendReceive(uint8_t data)
{
    while(!(SPI1->SR & SPI_SR_TXE));
    SPI1->DR = data;
    while(!(SPI1->SR & SPI_SR_RXNE));
    return SPI1->DR;
}

void SD_CS_Low(void)  { GPIO_ResetBits(SD_CS_GPIO, SD_CS_PIN); }
void SD_CS_High(void) { GPIO_SetBits(SD_CS_GPIO, SD_CS_PIN); }

static uint8_t SD_SendCmd(uint8_t cmd, uint32_t arg)
{
    uint8_t r1, retry = 0;
    SD_CS_Low();
    SD_SPI_SendReceive(cmd | 0x40);
    SD_SPI_SendReceive(arg >> 24);
    SD_SPI_SendReceive(arg >> 16);
    SD_SPI_SendReceive(arg >> 8);
    SD_SPI_SendReceive(arg);
    SD_SPI_SendReceive(cmd == 0 ? 0x95 : 0xFF);   // CMD0?0x95??
    do {
        r1 = SD_SPI_SendReceive(0xFF);
    } while((r1 & 0x80) && retry++ < 200);
    return r1;
}

uint8_t SD_Init(void)
{
    uint8_t i, r1;
    uint16_t retry = 0;

    SD_SPI_Init();
    SD_CS_High();

    for(i = 0; i < 80; i++) SD_SPI_SendReceive(0xFF);   // ????74???

    SD_CS_Low();
    do {
        r1 = SD_SendCmd(0, 0);                          // ??Idle??
    } while(r1 != 0x01 && retry++ < 1000);

    if(r1 != 0x01) return 1;

    // CMD8 ????
    if(SD_SendCmd(8, 0x1AA) == 0x01) {
        for(i=0;i<4;i++) SD_SPI_SendReceive(0xFF);
        if(SD_SPI_SendReceive(0xFF) != 0xAA) return 2;
    }

    // ACMD41 ???
    retry = 0;
    do {
        SD_SendCmd(55, 0);
        r1 = SD_SendCmd(41, 0x40000000);
    } while(r1 && retry++ < 1000);

    if(retry >= 1000) return 3;

    // CMD58 ??OCR,????
    if(SD_SendCmd(58, 0) == 0) {
        for(i=0;i<4;i++) SD_SPI_SendReceive(0xFF);
    }

    // ??SPI??
    SPI1->CR1 &= ~SPI_CR1_SPE;
    SPI1->CR1 &= ~(SPI_CR1_BR);
    SPI1->CR1 |= SPI_CR1_BR_0;          // ??4,?9MHz
    SPI1->CR1 |= SPI_CR1_SPE;

    SD_CS_High();
    SD_SPI_SendReceive(0xFF);
    return 0;   // ??
}

// ????????????(FatFS??????)
uint8_t SD_ReadSingleBlock(uint32_t sector, uint8_t *buffer)
{
    uint16_t i;
    uint8_t r1;

    if(SD_SendCmd(17, sector << 9) != 0) return 1;   // CMD17

    i = 0;
    do {
        r1 = SD_SPI_SendReceive(0xFF);
    } while(r1 == 0xFF && i++ < 3000);

    if(r1 != 0xFE) return 2;                        // ????????

    for(i = 0; i < 512; i++) buffer[i] = SD_SPI_SendReceive(0xFF);

    SD_SPI_SendReceive(0xFF);                       // CRC
    SD_SPI_SendReceive(0xFF);

    SD_CS_High();
    SD_SPI_SendReceive(0xFF);
    return 0;
}

uint8_t SD_WriteSingleBlock(uint32_t sector, uint8_t *buffer)
{
    uint16_t i;
    uint8_t r1;

    if(SD_SendCmd(24, sector << 9) != 0) return 1;   // CMD24

    SD_SPI_SendReceive(0xFE);                       // ??????

    for(i = 0; i < 512; i++) SD_SPI_SendReceive(buffer[i]);

    SD_SPI_SendReceive(0xFF);                       // CRC
    SD_SPI_SendReceive(0xFF);

    r1 = SD_SPI_SendReceive(0xFF);
    if((r1 & 0x1F) != 0x05) return 2;

    // ?????
    i = 0;
    do {
        r1 = SD_SPI_SendReceive(0xFF);
    } while(r1 == 0 && i++ < 100000);

    SD_CS_High();
    SD_SPI_SendReceive(0xFF);
    return 0;
}
