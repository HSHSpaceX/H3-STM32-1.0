#include "stm32f10x.h"
#include "Delay.h"
#include "OLED.h"
#include "MPU6050.h"
#include "Servo.h"
#include "math.h"
#include "ff.h"
#include "sd_spi.h"

extern volatile uint32_t millis;

FATFS fs;
FIL file;
uint32_t lastWriteTime = 0;

DWORD get_fattime(void)
{
    return ((DWORD)(2026 - 1980) << 25) |
           ((DWORD)2 << 21) |
           ((DWORD)13 << 16) |
           ((DWORD)0 << 11) |
           ((DWORD)0 << 5) |
           ((DWORD)0);
}

int main(void)
{
    SysTick_Config(SystemCoreClock / 1000);

    int16_t AX, AY, AZ;
    int16_t GX, GY, GZ;
    float PitchAngle;
    float RollAngle;
    float YawAngle = 0.0f;

    const float THRESHOLD = 30.0f;
    const uint8_t SERVO_ACTIVE_ANGLE = 90;
    const uint8_t SERVO_NORMAL_ANGLE = 0;

    uint8_t servoTriggered = 0;
    uint32_t triggerMillis = 0;
    uint8_t waitingReturn = 0;

    uint8_t sd_ok = 0;
    uint32_t lastGyroTime = 0;

    OLED_Init();
    MPU6050_Init();
    Servo_Init();

    OLED_ShowString(1, 1, "Pitch:");
    OLED_ShowString(2, 1, "Roll: ");
    OLED_ShowString(3, 1, "Servo:");
    OLED_ShowString(3, 7, "Normal ");

    Servo_SetAngle(SERVO_NORMAL_ANGLE);
    Delay_ms(200);
    if (SD_Init() == 0)
    {
        if (f_mount(&fs, "", 0) == FR_OK)
        {
            if (f_open(&file, "angles.txt", FA_CREATE_ALWAYS | FA_WRITE) == FR_OK)
            {
                f_printf(&file, "Time(ms),Roll_X(deg),Pitch_Y(deg),Yaw_Z(deg)\r\n");
                f_sync(&file);
                sd_ok = 1;
                OLED_ShowString(4, 1, "SD OK   ");
            }
            else
            {
                OLED_ShowString(4, 1, "Open Err");
            }
        }
        else
        {
            OLED_ShowString(4, 1, "Mount Err");
        }
    }
    else
    {
        OLED_ShowString(4, 1, "SD Init Err");
    }

    while (1)
    {
        MPU6050_GetAceel(&AX, &AY, &AZ);
        MPU6050_GetGyro(&GX, &GY, &GZ);

        PitchAngle = atan2f(-AX, sqrtf(AY * AY + AZ * AZ)) * 180.0f / 3.1415926535f;
        RollAngle = atan2f(sqrtf(GY*GY + GZ*GZ), GX) * 180.0f / 3.1415926535f;

        int16_t displayPitch = (int16_t)(PitchAngle + 0.5f * (PitchAngle >= 0 ? 1 : -1));
        int16_t displayRoll = (int16_t)(RollAngle + 0.5f * (RollAngle >= 0 ? 1 : -1));
        OLED_ShowNum(1, 7, displayPitch, 4);
        OLED_ShowNum(2, 7, displayRoll, 4);
        OLED_ShowString(1, 11, "deg ");
        OLED_ShowString(2, 11, "deg ");

        if (!waitingReturn)
        {
            if (fabsf(PitchAngle) > THRESHOLD || fabsf(RollAngle) > THRESHOLD)
            {
                if (!servoTriggered)
                {
                    Servo_SetAngle(SERVO_ACTIVE_ANGLE);
                    OLED_ShowString(3, 7, "Active ");
                    servoTriggered = 1;
                    triggerMillis = millis;
                    waitingReturn = 1;
                }
            }
        }
        else
        {
            if (millis - triggerMillis >= 10000)
            {
                Servo_SetAngle(SERVO_NORMAL_ANGLE);
                OLED_ShowString(3, 7, "Normal ");
                waitingReturn = 0;
                servoTriggered = 0;
            }
        }

        float dt = (millis - lastGyroTime) / 1000.0f;
        lastGyroTime = millis;
        if (dt > 0.0f && dt < 0.2f)
        {
            float deltaYaw = (float)GZ / 131.0f * dt;
            YawAngle += deltaYaw;
        }

        if (sd_ok && (millis - lastWriteTime >= 500))
        {
            f_printf(&file, "%lu,%.2f,%.2f,%.2f\r\n", millis, RollAngle, PitchAngle, YawAngle);
            f_sync(&file);
            lastWriteTime = millis;
        }

        Delay_ms(200);
    }
}
