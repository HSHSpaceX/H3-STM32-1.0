#include "stm32f10x.h"                  // Device header
#include "PWM.h"

void Servo_Init(void)
{
	PWM_Init();
}
void Servo_SetAngle(uint8_t Angle)
{
    PWM_SetCompare2(Angle * 2000 / 180 + 500);
}
